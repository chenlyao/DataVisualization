create function fun_branch() returns uuid
  language plpgsql
as
$$
begin
  return
  (select a.pk from web_branch a where a.dbuser=current_user limit 1);
end;
$$;

alter function fun_branch() owner to admin;

