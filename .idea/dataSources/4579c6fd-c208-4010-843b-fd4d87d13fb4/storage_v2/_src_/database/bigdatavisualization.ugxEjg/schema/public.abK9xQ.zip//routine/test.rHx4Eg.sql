create function test(id uuid) returns integer
  language plpgsql
as
$$
declare
  count integer;
begin
  count = (SELECT
             json_array_length(A.json::json -> 'features')
           FROM "Json" A
           WHERE A.uid = id);
  return count;
end;

$$;

alter function test(uuid) owner to admin;

